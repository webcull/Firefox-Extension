# Firefox-Extension
An easy way to save to WebCull in Firefox

Extension API:
https://github.com/webcull/Extension-API
